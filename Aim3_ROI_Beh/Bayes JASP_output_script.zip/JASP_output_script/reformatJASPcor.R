# This script simply reads in output pasted from JASP
# for each Phenotype~ROI relationship and arranges it into 
# a format that makes it easier to summarize and report.

# read in r values and CIs from JASP
Int.dat<-read.csv("InternalizingJASP.csv",header = FALSE)
Ext.dat<-read.csv("ExternalizingJASP.csv",header = FALSE)
Subst.dat<-read.csv("SubUse.csv",header = FALSE)
BISB.dat<-read.csv("BISB.csv",header = FALSE)
BSSS.dat<-read.csv("BSSS.csv",header = FALSE)

# get rid of weird "ACC1" symbol upon read-in
# and make sure columns are consistent
Int.dat[,1]<-Ext.dat[,1]
Subst.dat[,1]<-Ext.dat[,1]
BISB.dat[,1]<-Ext.dat[,1]
BSSS.dat[,1]<-Ext.dat[,1]


# make summary data set 

roi.names<-as.character(unique(Ext.dat$V1))
roi.names<-roi.names[roi.names!=""]

sum.dat<-data.frame(
  rep(roi.names,5),
  c(rep("Internalizing",80),rep("Externalizing",80),
    rep("SubUse",80),rep("BISB",80),rep("BSSS",80))
)

colnames(sum.dat)<-c("ROI","Pheno")

sum.dat$Med.r<-NA
sum.dat$Upper.CI<-NA
sum.dat$Lower.CI<-NA

for (r in roi.names){
  Int.tmp<-Int.dat[as.numeric(rownames(Int.dat[Int.dat$V1==r,]))+c(0,1,2),]
  Ext.tmp<-Ext.dat[as.numeric(rownames(Ext.dat[Ext.dat$V1==r,]))+c(0,1,2),]
  Subst.tmp<-Subst.dat[as.numeric(rownames(Subst.dat[Subst.dat$V1==r,]))+c(0,1,2),]
  BISB.tmp<-BISB.dat[as.numeric(rownames(BISB.dat[BISB.dat$V1==r,]))+c(0,1,2),]
  BSSS.tmp<-BSSS.dat[as.numeric(rownames(BSSS.dat[BSSS.dat$V1==r,]))+c(0,1,2),]

  sum.dat[sum.dat$ROI==r & sum.dat$Pheno=="Internalizing",3:5]<-Int.tmp[,4]
  sum.dat[sum.dat$ROI==r & sum.dat$Pheno=="Externalizing",3:5]<-Ext.tmp[,4]
  sum.dat[sum.dat$ROI==r & sum.dat$Pheno=="SubUse",3:5]<-Subst.tmp[,4]
  sum.dat[sum.dat$ROI==r & sum.dat$Pheno=="BISB",3:5]<-BISB.tmp[,4]
  sum.dat[sum.dat$ROI==r & sum.dat$Pheno=="BSSS",3:5]<-BSSS.tmp[,4]
  
}

#write out

write.csv(sum.dat,file="pheno_bayes_cor.csv",row.names = FALSE)
